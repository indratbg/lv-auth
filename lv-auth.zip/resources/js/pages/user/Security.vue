<template>
    <div>
        <h1>Halaman Security</h1>
    </div>
</template>
<script>
export default {};
</script>
