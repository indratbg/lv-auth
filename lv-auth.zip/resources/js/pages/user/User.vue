<template>
  <div>
    <div class="card text-left">
      <div class="card-body">
        <h1>This is user dashboard</h1>
      </div>
    </div>
  </div>
</template>
<script>
export default {};
</script>
