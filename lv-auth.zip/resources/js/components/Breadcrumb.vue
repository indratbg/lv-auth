<template>
  <div></div>
</template>
<script>
export default {
  mounted() {
    console.log("Breadcrumb");
  }
};
</script>
