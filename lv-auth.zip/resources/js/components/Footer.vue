<template>
  <div>
      <div class="clearfix"><hr></div>
      <div class="container-fluid" style="background-color:#DEDEE0 ">
    <div class="row">
        <div class="col-md-4">
            <div class="card-body">
                <h3 class="card-title">About</h3>
                <div class="card-text">
                    <ul class="list-group">
                        <li class="list-group-item">Item 1</li>
                        <li class="list-group-item">Item 1</li>
                        <li class="list-group-item">Item 1</li>
                        <li class="list-group-item">Item 1</li>

                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card-body">
                <h3 class="card-title">About</h3>
                <div class="card-text">
                    <ul class="list-group">
                        <li class="list-group-item">Item 1</li>
                        <li class="list-group-item">Item 1</li>
                        <li class="list-group-item">Item 1</li>
                        <li class="list-group-item">Item 1</li>

                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card-body">
                <h3 class="card-title">About</h3>
                <div class="card-text">
                    <ul class="list-group">
                        <li class="list-group-item">Item 1</li>
                        <li class="list-group-item">Item 1</li>
                        <li class="list-group-item">Item 1</li>
                        <li class="list-group-item">Item 1</li>

                    </ul>
                </div>
            </div>
        </div>
    </div>
  </div>
  </div>
</template>
<script>
export default {};
</script>
